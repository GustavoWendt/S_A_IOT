// Inicializa o display LCD com endereço I2C 0x27, 16 colunas e 2 linhas
LiquidCrystal_I2C lcd(0x27, 16, 2);

// Variável para armazenar o tempo da última atualização do display
unsigned long int t_display;

// Função para inicializar o display
void inicia_display() {
  lcd.init();
  lcd.backlight();
}

// Função para atualizar o display
void scan_display() {

  // Atualiza a cada 1 segundo
  if (millis() - t_display > 1000) {
    t_display = millis();

    lcd.clear();

    // Exibe a temperatura
    lcd.setCursor(0, 0);
    lcd.print("Temperatura: ");
    lcd.print(temperatura);
    lcd.print("C");

    // Exibe a umidade
    lcd.setCursor(0, 1);
    lcd.print("Umidade: ");
    lcd.print(humidade);
    lcd.print("%");
  }
}
