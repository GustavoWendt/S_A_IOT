// LDR (Sensor de Luz)
int ldr = A0;                  // Define o pino analógico A0 para o sensor LDR
bool dia = false;              // Variável para armazenar se é dia (true) ou noite (false)
void scan_ldr();               // Declaração da função para ler o sensor LDR

// Sensor de Chuva
const int chuva = A1;          // Define o pino analógico A1 para o sensor de chuva
bool chovendo = false;         // Variável para armazenar se está chovendo (true) ou não (false)
void scan_chuva();             // Declaração da função para ler o sensor de chuva
float mapFloat(float x, float in_min, float in_max, float out_min, float out_max); // Declaração da função para mapear valores float

// Sensor DHT (Temperatura e Umidade)
DHT dht(3, DHT11);             // Cria um objeto DHT no pino digital 3 para o sensor DHT11
float temperatura;             // Variável para armazenar a temperatura lida
float humidade;                // Variável para armazenar a umidade lida
unsigned long int t_dht;       // Variável para armazenar o tempo da última leitura do DHT
void scan_dht();               // Declaração da função para ler o sensor DHT


// Botões
const int pin_btn_on = 4;      // Define o pino digital 4 para o botão "Ligar"
unsigned long int t_btn_on;    // Variável para armazenar o tempo do último acionamento do botão "Ligar"
bool btn_on_ready = false;     // Variável para evitar leituras repetidas do botão "Ligar"
bool force_on = false;         // Variável para forçar a ativação do motor

const int pin_btn_off = 5;     // Define o pino digital 5 para o botão "Desligar"
unsigned long int t_btn_off;   // Variável para armazenar o tempo do último acionamento do botão "Desligar"
bool btn_off_ready = false;    // Variável para evitar leituras repetidas do botão "Desligar"
bool force_off = false;        // Variável para forçar a desativação do motor

bool motor_aberto = false;     // Variável para armazenar se o motor está aberto
bool motor_fechado = false;    // Variável para armazenar se o motor está fechado
void scan_btn();               // Declaração da função para ler os botões

const int pin_automatico = 6;  // Define o pino digital 6 para o modo automático
bool automatico = false;       // Variável para armazenar se o modo automático está ativado

bool auto_ready = false; // evita múltiplas leituras
unsigned long int t_btn_auto = 0; // debounce do botão automático


// Funções de inicialização e leitura de sensores
void inicia_sensores();        // Declaração da função para inicializar os sensores
void scan_sensores();          // Declaração da função para ler todos os sensores

// Função para inicializar os sensores
void inicia_sensores() {
  // Configura o pino do modo automático como entrada com resistor pull-up interno
  pinMode(pin_automatico, INPUT_PULLUP);

  // Configura o pino do LDR como entrada
  pinMode(ldr, INPUT);

  // Configura o pino do sensor de chuva como entrada
  pinMode(chuva, INPUT);

  // Inicializa o sensor DHT
  dht.begin();



  // Configura os pinos dos botões como entrada com resistor pull-up interno
  pinMode(pin_btn_on, INPUT_PULLUP);
  pinMode(pin_btn_off, INPUT_PULLUP);
}

// Função para ler os botões
// Variável global para armazenar estado anterior do botão automático
bool lastAutomaticoState = HIGH; 

void scan_btn() {
 // ---------------- BOTÕES MANUAIS ----------------
if (!automatico) {
 // Botão "Ligar"
if (!digitalRead(pin_btn_on)) {
if ((millis() - t_btn_on > 300) && !btn_on_ready) {
Serial.println(" BTN ABRE");
 btn_on_ready = true;
 force_on = true;
} else {
 t_btn_on = millis();
 btn_on_ready = false;
}
}
 // Botão "Desligar"
if (!digitalRead(pin_btn_off)) {
if ((millis() - t_btn_off > 300) && !btn_off_ready) {
Serial.println(" BTN FECHA");
 btn_off_ready = true;
 force_off = true;
} else {
 t_btn_off = millis();
 btn_off_ready = false;
}
}
}
// BOTÃO AUTOMÁTICO (TOGGLE)
if (!digitalRead(pin_automatico)) { // botão pressionado
    if ((millis() - t_btn_auto > 300) && !auto_ready) {
        automatico = !automatico; // alterna o modo
        Serial.print("Modo automatico: ");
        Serial.println(automatico ? "ON" : "OFF");
        auto_ready = true;
        t_btn_auto = millis(); // debounce correto
    }
} 
else {
    auto_ready = false; // libera para a próxima vez
    // NÃO atualize t_btn_auto aqui!
}

}



// Função para ler todos os sensores
void scan_sensores() {
  scan_ldr();   // Lê o sensor LDR
  scan_dht(); // (Comentado) Lê o sensor DHT
  scan_chuva(); // Lê o sensor de chuva
}

// Função para ler o sensor LDR
void scan_ldr() {
  // Verifica se a leitura do LDR indica dia ou noite
  if (analogRead(ldr) < 800) {  // Se a leitura for menor que 800, é dia
    dia = true;                 // Marca como dia
    Serial.println(" DIA");  // (Comentado) Envia mensagem para o monitor serial
  } else {
    dia = false;                // Marca como noite
     Serial.println(" NOITE"); // (Comentado) Envia mensagem para o monitor serial
  }
}

// Função para ler o sensor de chuva
void scan_chuva() {
  // Verifica se a leitura do sensor de chuva indica chuva
  if (analogRead(chuva) < 700) {  // Se a leitura for menor que 1000, está chovendo
    chovendo = true;               // Marca como chovendo
    Serial.println(" chovendo"); // (Comentado) Envia mensagem para o monitor serial
  } else {
    chovendo = false;              // Marca como não chovendo
     Serial.println(" nao chovendo"); // (Comentado) Envia mensagem para o monitor serial
  }
}

// Função para ler o sensor DHT
void scan_dht() {
  if (millis() - t_dht > 1000) {
    t_dht = millis();
    temperatura = dht.readTemperature();
    humidade = dht.readHumidity();

    if (isnan(temperatura) || isnan(humidade)) {
      Serial.println("Erro no DHT!");
      return;
    }
  }
}



// Função para mapear valores float
float mapFloat(float x, float in_min, float in_max, float out_min, float out_max) {
  float valor = (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
  return valor > 0 ? valor : 0.0;  // Retorna o valor mapeado, garantindo que não seja negativo
}