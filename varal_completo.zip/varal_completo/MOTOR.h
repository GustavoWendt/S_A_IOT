// Define o número de passos por revolução do motor de passo
const int stepsPerRevolution = 65; // Número de passos que o motor precisa para dar uma volta completa

// Inicializa o motor de passo utilizando os pinos digitais 8, 9, 10 e 11
Stepper myStepper(stepsPerRevolution, 8, 10, 9, 11); // Os pinos 8, 9, 10 e 11 controlam o motor

// Variável para armazenar o status do motor (true = ligado, false = desligado)
bool status_motor = false;

// Declaração das funções para inicializar e controlar o motor
void inicia_motor();  // Função para configurar o motor
void scan_motor();    // Função para controlar o motor com base nas condições

// Função para inicializar o motor
void inicia_motor() {
  myStepper.setSpeed(400);  // Define a velocidade do motor em RPM (rotações por minuto)
}

// Função para controlar o motor com base no modo automático ou manual
void scan_motor() {
  // Modo automático
  if (automatico) {

      // CONDIÇÃO DE ABERTURA
      if (dia && !chovendo && temperatura >= 25 && humidade <= 60 && !motor_aberto) {

          Serial.println("Motor abre");
          for (int i = 0; i < 50; i++) {
              myStepper.step(stepsPerRevolution);
          }
          motor_aberto = true;
          motor_fechado = false;
      }

      // CONDIÇÃO DE FECHAMENTO
      else if ((!dia || chovendo || temperatura < 25 || humidade > 60) && !motor_fechado) {

          Serial.println("Motor fecha");
          for (int i = 0; i < 50; i++) {
              myStepper.step(-stepsPerRevolution);
          }
          motor_fechado = true;
          motor_aberto = false;
      }
  }

  // Modo manual
  else {
    // Verifica se o botão "Ligar" foi pressionado (force_on = true)
    // e se o motor não está aberto (motor_aberto = false)
    if (force_on && !motor_aberto) {
      Serial.println("Motor abre");  // Exibe mensagem no monitor serial
      // Move o motor para abrir (50 passos no sentido horário)
      for (int i = 0; i < 50; i++) {
        myStepper.step(stepsPerRevolution);  // Realiza um passo no sentido horário
      }
      motor_aberto = true;   // Marca que o motor está aberto
      motor_fechado = false;  // Marca que o motor não está fechado
      force_on = false;       // Reseta a flag de força para abrir
    }
    // Verifica se o botão "Desligar" foi pressionado (force_off = true)
    // e se o motor não está fechado (motor_fechado = false)
    else if (force_off && !motor_fechado) {
      Serial.println("Motor fecha");  // Exibe mensagem no monitor serial
      // Move o motor para fechar (50 passos no sentido anti-horário)
      for (int i = 0; i < 50; i++) {
        myStepper.step(-stepsPerRevolution);  // Realiza um passo no sentido anti-horário
      }
      motor_fechado = true;  // Marca que o motor está fechado
      motor_aberto = false;  // Marca que o motor não está aberto
      force_off = false;     // Reseta a flag de força para fechar
    }
  }
}