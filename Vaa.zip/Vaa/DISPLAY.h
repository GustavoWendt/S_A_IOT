// Inicializa o display LCD com endereço I2C 0x27, 16 colunas e 2 linhas
LiquidCrystal_I2C lcd(0x27, 16, 2);

// Variável para armazenar o tempo da última atualização do display
unsigned long int t_display;

// Variável para controlar o estado do display (alterna entre 0 e 1)
int displayState = 0;

// Declaração da função para inicializar o display
void inicia_display();

// Função para inicializar o display
void inicia_display() {
  lcd.init();       // Inicializa o display LCD
  lcd.backlight();  // Liga a luz de fundo do display
}

// Função para atualizar o display com informações
void scan_display() {
  // Verifica se já passou 1 segundo desde a última atualização
  if (millis() - t_display > 1000) {
    t_display = millis();  // Atualiza o tempo da última atualização
    displayState = !displayState;  // Alterna o estado do display (0 ou 1)

    lcd.clear();  // Limpa o display para exibir novas informações


      // Exibe a temperatura na primeira linha
      lcd.setCursor(0, 0);          // Posiciona o cursor na primeira linha, coluna 0
      lcd.print("Temperatura:");    // Exibe o texto "Temperatura:"
      lcd.print(temperatura);       // Exibe o valor da temperatura
      lcd.print("C");               // Exibe o caractere "C" (Celsius)

      // Exibe a umidade na segunda linha
      lcd.setCursor(0, 1);          // Posiciona o cursor na segunda linha, coluna 0
      lcd.print("Umidade: ");       // Exibe o texto "Umidade: "
      lcd.print(humidade);          // Exibe o valor da umidade
      lcd.print("%");               // Exibe o caractere "%"
    }
  }
}